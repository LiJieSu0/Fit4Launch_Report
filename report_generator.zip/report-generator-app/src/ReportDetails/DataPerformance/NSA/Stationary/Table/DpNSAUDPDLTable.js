import React from 'react';
import { getKpiCellColor } from '../../../../../Utils/KpiRules';

function DpNSAUDPDLTable({ data, tableName }) {
  const calculateOverallAverage = (moderate, poor) => {
    const moderateVal = parseFloat(moderate);
    const poorVal = parseFloat(poor);
    if (isNaN(moderateVal) || isNaN(poorVal)) {
      return "N/A";
    }
    return ((moderateVal + poorVal) / 2).toFixed(2);
  };

  const getRowSpan = (currentMetric, currentIdealThroughput) => {
    let count = 0;
    for (let i = 0; i < data.length; i++) {
      if (data[i].metric === currentMetric && data[i].idealThroughput === currentIdealThroughput) {
        count++;
      }
    }
    return count;
  };

  const getMetricRowSpan = (currentMetric) => {
    let count = 0;
    for (let i = 0; i < data.length; i++) {
      if (data[i].metric === currentMetric) {
        count++;
      }
    }
    return count;
  };

  let lastMetric = null;
  let lastIdealThroughput = null;

  return (
    <div className="">
      <h4>{tableName}</h4>
      <table className="general-table-style udp-stationary-details-table">
        <thead>
          <tr>
            <th rowSpan="2">Metric</th>
            <th rowSpan="2">Ideal Throughput</th>
            <th rowSpan="2">Device Name</th>
            <th rowSpan="2">Overall</th>
            <th colSpan="2">Location</th>
          </tr>
          <tr>
            <th>Moderate</th>
            <th>Poor</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, index) => {
            const showMetric = row.metric !== lastMetric;
            const showIdealThroughput = row.idealThroughput !== lastIdealThroughput || showMetric;

            if (showMetric) {
              lastMetric = row.metric;
              lastIdealThroughput = row.idealThroughput;
            } else if (showIdealThroughput) {
              lastIdealThroughput = row.idealThroughput;
            }

            const refRow = data.find(
              (item) =>
                item.metric === row.metric &&
                item.idealThroughput === row.idealThroughput &&
                item.deviceName === 'REF'
            );

            const refOverallValue = refRow ? calculateOverallAverage(refRow.location?.moderate, refRow.location?.poor) : null;
            const currentOverallValue = calculateOverallAverage(row.location?.moderate, row.location?.poor);

            return (
              <tr key={index}>
                {showMetric && (
                  <td rowSpan={getMetricRowSpan(row.metric)}>{row.metric}</td>
                )}
                {showIdealThroughput && (
                  <td rowSpan={getRowSpan(row.metric, row.idealThroughput)}>{row.idealThroughput}</td>
                )}
                <td>{row.deviceName}</td>
                <td style={{
                  backgroundColor: row.deviceName === 'DUT' && refOverallValue !== null && !row.metric.includes('Max Throughput')
                    ? getKpiCellColor(
                      row.metric === 'Mean Jitter (s)' ? 'Jitter' :
                        row.metric === 'Packet Failure Rate (%)' ? 'ErrorRatio' :
                          'Throughput',
                      parseFloat(currentOverallValue),
                      parseFloat(refOverallValue)
                    )
                    : 'inherit'
                }}>
                  {currentOverallValue}
                </td>
                <td style={{
                  backgroundColor: row.deviceName === 'DUT' && refRow?.location?.moderate !== undefined && !row.metric.includes('Max Throughput')
                    ? getKpiCellColor(
                      row.metric === 'Mean Jitter (s)' ? 'Jitter' :
                        row.metric === 'Packet Failure Rate (%)' ? 'ErrorRatio' :
                          'Throughput',
                      parseFloat(row.location.moderate),
                      parseFloat(refRow.location.moderate)
                    )
                    : 'inherit'
                }}>
                  {typeof row.location?.moderate === 'number' ? row.location.moderate.toFixed(2) : (row.location?.moderate || "0.00")}
                </td>
                <td style={{
                  backgroundColor: row.deviceName === 'DUT' && refRow?.location?.poor !== undefined && !row.metric.includes('Max Throughput')
                    ? getKpiCellColor(
                      row.metric === 'Mean Jitter (s)' ? 'Jitter' :
                        row.metric === 'Packet Failure Rate (%)' ? 'ErrorRatio' :
                          'Throughput',
                      parseFloat(row.location.poor),
                      parseFloat(refRow.location.poor)
                    )
                    : 'inherit'
                }}>
                  {typeof row.location?.poor === 'number' ? row.location.poor.toFixed(2) : (row.location?.poor || "0.00")}
                </td>
              </tr>
            );

          })}
        </tbody>
      </table>
    </div>
  );
}

export default DpNSAUDPDLTable;