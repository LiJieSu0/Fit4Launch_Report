import React from 'react';
import DpDriveTestTable from './DpDriveTestTable';
import DpMHSTestDriveTable from '../MHS/Table/DpMHSTestDriveTable';
import DpDriveTestOverallTable from './DpDriveTestOverallTable';
import DpMHSTestDriveOverallTable from '../MHS/Table/DpMHSTestDriveOverallTable';
import DpHistogramComponent from '../DpHistogramComponent';
import { CHART_COLOR_DUT, CHART_COLOR_REF } from '../../../Constants/ChartColors';
import { ReportContext } from '../../../Contexts/ReportContext';
import { useContext } from 'react';
import DynamicHeader from '../../../CommonPage/DynamicHeader';

import { useEffect } from 'react';

const DpDriveTestDetailPage = ({ city: propCity }) => {
  const { city: globalCity, allReportData, loadCityData } = useContext(ReportContext);
  const city = propCity || globalCity;

  useEffect(() => {
    if (city) {
      loadCityData(city);
    }
  }, [city, loadCityData]);

  const reportData = allReportData[city];

  if (!reportData || !reportData.dataPerformance) {
    return <div className="page-content">Loading {city} data...</div>;
  }

  // Access Mobility Test data from the new JSON structure
  const mobilityTestData = reportData.dataPerformance?.['Data Performance']?.['5G AUTO DP']?.['Mobility Test'];

  if (!mobilityTestData) {
    return <div className="page-content">No Mobility Test Data available</div>;
  }

  // Get the 5G Auto Data Test Drive data
  const testDriveData = mobilityTestData?.['5G Auto Data Test Drive'];
  const dutDriveTest = testDriveData?.['DUT'];
  const refDriveTest = testDriveData?.['REF'];

  const getDriveTestMetricData = (metricName, dutValue, refValue) => {
    return [{ name: metricName, DUT: dutValue || 0, REF: refValue || 0 }];
  };

  // Prepare data for tables and charts - handle the new simpler structure
  const driveTestThroughputData = getDriveTestMetricData(
    "Throughput",
    dutDriveTest?.Throughput?.Mean,
    refDriveTest?.Throughput?.Mean
  );
  const driveTestJitterData = getDriveTestMetricData(
    "Jitter",
    dutDriveTest?.Jitter?.Mean,
    refDriveTest?.Jitter?.Mean
  );
  const driveTestErrorRatioData = getDriveTestMetricData(
    "Error Ratio",
    dutDriveTest?.['Error Ratio']?.Mean,
    refDriveTest?.['Error Ratio']?.Mean
  );

  // Format the TestDriveData for the table components (matching expected structure)
  const formattedTestDriveData = {
    "DUT UDP DL": {
      Throughput: {
        Mean: dutDriveTest?.Throughput?.Mean || 0,
        Minimum: dutDriveTest?.Throughput?.Minimum || 0,
        Maximum: dutDriveTest?.Throughput?.Maximum || 0,
        'Standard Deviation': dutDriveTest?.Throughput?.['Standard Deviation'] || 0,
      },
      Jitter: {
        Mean: dutDriveTest?.Jitter?.Mean || 0,
      },
      'Error Ratio': {
        Mean: dutDriveTest?.['Error Ratio']?.Mean || 0,
      },
    },
    "REF UDP DL": {
      Throughput: {
        Mean: refDriveTest?.Throughput?.Mean || 0,
        Minimum: refDriveTest?.Throughput?.Minimum || 0,
        Maximum: refDriveTest?.Throughput?.Maximum || 0,
        'Standard Deviation': refDriveTest?.Throughput?.['Standard Deviation'] || 0,
      },
      Jitter: {
        Mean: refDriveTest?.Jitter?.Mean || 0,
      },
      'Error Ratio': {
        Mean: refDriveTest?.['Error Ratio']?.Mean || 0,
      },
    },
  };

  // Check if MHS Test Drive data exists - use the correct key from JSON
  const mhsTestDriveData = mobilityTestData?.['5G Auto Data Test MHS Drive'];
  const dutMHS = mhsTestDriveData?.['DUT'];
  const refMHS = mhsTestDriveData?.['REF'];
  const hasMhsData = dutMHS && refMHS;

  // Format MHS data for table components (matching expected structure)
  const formattedMhsTestDriveData = hasMhsData ? {
    "DUT UDP DL": {
      Throughput: {
        DL: {
          Mean: dutMHS?.['DL Throughput']?.Mean || 0,
          Minimum: dutMHS?.['DL Throughput']?.Minimum || 0,
          Maximum: dutMHS?.['DL Throughput']?.Maximum || 0,
          'Standard Deviation': dutMHS?.['DL Throughput']?.['Standard Deviation'] || 0,
        },
        UL: {
          Mean: dutMHS?.['UL Throughput']?.Mean || 0,
          Minimum: dutMHS?.['UL Throughput']?.Minimum || 0,
          Maximum: dutMHS?.['UL Throughput']?.Maximum || 0,
          'Standard Deviation': dutMHS?.['UL Throughput']?.['Standard Deviation'] || 0,
        },
      },
      Jitter: {
        'DL Mean': dutMHS?.['DL Jitter']?.Mean || 0,
        'UL Mean': dutMHS?.['UL Jitter']?.Mean || 0,
      },
      'Error Ratio': {
        'DL Mean': dutMHS?.['DL Error Ratio']?.Mean || 0,
        'UL Mean': dutMHS?.['UL Error Ratio']?.Mean || 0,
      },
      'Ping RTT': {
        avg: dutMHS?.['Ping RTT']?.Mean || 0,
        min: dutMHS?.['Ping RTT']?.Min || 0,
        max: dutMHS?.['Ping RTT']?.Max || 0,
        std_dev: dutMHS?.['Ping RTT']?.['Std Dev'] || 0,
      },
    },
    "REF UDP DL": {
      Throughput: {
        DL: {
          Mean: refMHS?.['DL Throughput']?.Mean || 0,
          Minimum: refMHS?.['DL Throughput']?.Minimum || 0,
          Maximum: refMHS?.['DL Throughput']?.Maximum || 0,
          'Standard Deviation': refMHS?.['DL Throughput']?.['Standard Deviation'] || 0,
        },
        UL: {
          Mean: refMHS?.['UL Throughput']?.Mean || 0,
          Minimum: refMHS?.['UL Throughput']?.Minimum || 0,
          Maximum: refMHS?.['UL Throughput']?.Maximum || 0,
          'Standard Deviation': refMHS?.['UL Throughput']?.['Standard Deviation'] || 0,
        },
      },
      Jitter: {
        'DL Mean': refMHS?.['DL Jitter']?.Mean || 0,
        'UL Mean': refMHS?.['UL Jitter']?.Mean || 0,
      },
      'Error Ratio': {
        'DL Mean': refMHS?.['DL Error Ratio']?.Mean || 0,
        'UL Mean': refMHS?.['UL Error Ratio']?.Mean || 0,
      },
      'Ping RTT': {
        avg: refMHS?.['Ping RTT']?.Mean || 0,
        min: refMHS?.['Ping RTT']?.Min || 0,
        max: refMHS?.['Ping RTT']?.Max || 0,
        std_dev: refMHS?.['Ping RTT']?.['Std Dev'] || 0,
      },
    },
  } : null;

  // MHS histogram data
  const mhsDLThroughputData = hasMhsData ? getDriveTestMetricData(
    "DL Throughput",
    dutMHS?.['DL Throughput']?.Mean,
    refMHS?.['DL Throughput']?.Mean
  ) : [];
  const mhsDLJitterData = hasMhsData ? getDriveTestMetricData(
    "DL Jitter",
    dutMHS?.['DL Jitter']?.Mean,
    refMHS?.['DL Jitter']?.Mean
  ) : [];
  const mhsDLErrorRatioData = hasMhsData ? getDriveTestMetricData(
    "DL Error Ratio",
    dutMHS?.['DL Error Ratio']?.Mean,
    refMHS?.['DL Error Ratio']?.Mean
  ) : [];
  const mhsPingRttData = hasMhsData ? getDriveTestMetricData(
    "Ping RTT",
    dutMHS?.['Ping RTT']?.Mean,
    refMHS?.['Ping RTT']?.Mean
  ) : [];

  return (
    <>
      <div className='page-content'>
        <DynamicHeader level={3}>Mobility Test - 5G Auto - {city}</DynamicHeader>
        <DpDriveTestOverallTable data={formattedTestDriveData} tableName="Mobility Test Drive Overview" />
        <DpDriveTestTable data={formattedTestDriveData} tableName="Mobility Test Drive Details" />
      </div>
      <div className='page-content'>
        <DpHistogramComponent
          data={driveTestThroughputData}
          title="Mobility Test Drive Throughput"
          yAxisLabel="Throughput (Mbps)"
          barKeys={[{ key: 'DUT', fill: CHART_COLOR_DUT }, { key: 'REF', fill: CHART_COLOR_REF }]}
        />
        <DpHistogramComponent
          data={driveTestJitterData}
          title="Mobility Test Drive Jitter"
          yAxisLabel="Jitter (s)"
          barKeys={[{ key: 'DUT', fill: CHART_COLOR_DUT }, { key: 'REF', fill: CHART_COLOR_REF }]}
        />
      </div>
      <div className='page-content'>
        <DpHistogramComponent
          data={driveTestErrorRatioData}
          title="Mobility Test Drive Packet Failure Rate"
          yAxisLabel="Packet Failure Rate (%)"
          barKeys={[{ key: 'DUT', fill: CHART_COLOR_DUT }, { key: 'REF', fill: CHART_COLOR_REF }]}
        />
      </div>

      {hasMhsData ? (
        <>
          <div className='page-content'>
            <DynamicHeader level={3}>Mobility Test - Mobile Hotspot - 5G Auto - {city}</DynamicHeader>
            <DpMHSTestDriveOverallTable data={formattedMhsTestDriveData} tableName="MHS Test Drive Overall Data" />
            <DpMHSTestDriveTable data={formattedMhsTestDriveData} tableName="MHS Test Drive Data" />
          </div>
          <div className='page-content'>
            <DpHistogramComponent
              data={mhsDLThroughputData}
              title="MHS Test Drive - DL Throughput"
              yAxisLabel="Throughput (Mbps)"
              barKeys={[{ key: 'DUT', fill: CHART_COLOR_DUT }, { key: 'REF', fill: CHART_COLOR_REF }]}
            />
            <DpHistogramComponent
              data={mhsDLJitterData}
              title="MHS Test Drive - DL Jitter"
              yAxisLabel="Jitter (ms)"
              barKeys={[{ key: 'DUT', fill: CHART_COLOR_DUT }, { key: 'REF', fill: CHART_COLOR_REF }]}
            />
          </div>
          <div className='page-content'>
            <DpHistogramComponent
              data={mhsDLErrorRatioData}
              title="MHS Test Drive - DL Packet Failure Rate"
              yAxisLabel="Packet Failure Rate (%)"
              barKeys={[{ key: 'DUT', fill: CHART_COLOR_DUT }, { key: 'REF', fill: CHART_COLOR_REF }]}
            />
            <DpHistogramComponent
              data={mhsPingRttData}
              title="MHS Test Drive - Mean Ping RTT"
              yAxisLabel="RTT (ms)"
              barKeys={[{ key: 'DUT', fill: CHART_COLOR_DUT }, { key: 'REF', fill: CHART_COLOR_REF }]}
            />
          </div>
        </>
      ) : (
        <div className='page-content'>
          <DynamicHeader level={3}>Mobility Test - Mobile Hotspot</DynamicHeader>
          <p>No MHS Test Drive Data available</p>
        </div>
      )}
    </>
  );
};

export default DpDriveTestDetailPage;

