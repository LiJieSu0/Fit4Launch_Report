import React from 'react';
import DpDetailsTableLoc3 from './Table/DpDetailsTableLoc3';
import DpThroughputOverallTable from '../DpThroughputOverallTable';
import DpRangeChart from '../DpRangeChart';
import DpHistogramComponent from '../DpHistogramComponent';
import { ReportContext } from '../../../Contexts/ReportContext';
import { useContext } from 'react';
import { CHART_COLOR_DUT, CHART_COLOR_REF } from '../../../Constants/ChartColors';
import DynamicHeader from '../../../CommonPage/DynamicHeader';

import { useEffect } from 'react';

function Dp_httpSS_Component({ city: propCity, firstSection = false }) {
  const { city: globalCity, allReportData, loadCityData } = useContext(ReportContext);
  const city = propCity || globalCity;

  useEffect(() => {
    if (city) {
      loadCityData(city);
    }
  }, [city, loadCityData]);

  const reportData = allReportData[city];

  // Update to use dataPerformance from the fetched JSON
  if (!reportData || !reportData.dataPerformance) {
    return <div className="page-content">Loading {city} data...</div>;
  }

  // Path: ["Data Performance"]["5G AUTO DP"]["HTTP Single Stream"]
  const httpSS_Data_Source = reportData.dataPerformance["Data Performance"]["5G AUTO DP"]["HTTP Single Stream"];

  const httpSS_Stationary_DL = {
    Good: {
      DUT: httpSS_Data_Source.DL.Good.DUT.Throughput,
      REF: httpSS_Data_Source.DL.Good.REF.Throughput,
    },
    Moderate: {
      DUT: httpSS_Data_Source.DL.Moderate.DUT.Throughput,
      REF: httpSS_Data_Source.DL.Moderate.REF.Throughput,
    },
    Poor: {
      DUT: httpSS_Data_Source.DL.Poor.DUT.Throughput,
      REF: httpSS_Data_Source.DL.Poor.REF.Throughput,
    },
  };

  const httpSS_Stationary_UL = {
    Good: {
      DUT: httpSS_Data_Source.UL.Good.DUT.Throughput,
      REF: httpSS_Data_Source.UL.Good.REF.Throughput,
    },
    Moderate: {
      DUT: httpSS_Data_Source.UL.Moderate.DUT.Throughput,
      REF: httpSS_Data_Source.UL.Moderate.REF.Throughput,
    },
    Poor: {
      DUT: httpSS_Data_Source.UL.Poor.DUT.Throughput,
      REF: httpSS_Data_Source.UL.Poor.REF.Throughput,
    },
  };

  const dlRangeChartData = {
    Good: {
      dutMin: httpSS_Stationary_DL.Good.DUT.Minimum,
      dutMax: httpSS_Stationary_DL.Good.DUT.Maximum,
      refMin: httpSS_Stationary_DL.Good.REF.Minimum,
      refMax: httpSS_Stationary_DL.Good.REF.Maximum,
      dutMean: httpSS_Stationary_DL.Good.DUT.Mean,
      refMean: httpSS_Stationary_DL.Good.REF.Mean,
    },
    Moderate: {
      dutMin: httpSS_Stationary_DL.Moderate.DUT.Minimum,
      dutMax: httpSS_Stationary_DL.Moderate.DUT.Maximum,
      refMin: httpSS_Stationary_DL.Moderate.REF.Minimum,
      refMax: httpSS_Stationary_DL.Moderate.REF.Maximum,
      dutMean: httpSS_Stationary_DL.Moderate.DUT.Mean,
      refMean: httpSS_Stationary_DL.Moderate.REF.Mean,
    },
    Poor: {
      dutMin: httpSS_Stationary_DL.Poor.DUT.Minimum,
      dutMax: httpSS_Stationary_DL.Poor.DUT.Maximum,
      refMin: httpSS_Stationary_DL.Poor.REF.Minimum,
      refMax: httpSS_Stationary_DL.Poor.REF.Maximum,
      dutMean: httpSS_Stationary_DL.Poor.DUT.Mean,
      refMean: httpSS_Stationary_DL.Poor.REF.Mean,
    },
    Overall: {
      dutMin: Math.min(httpSS_Stationary_DL.Good.DUT.Minimum, httpSS_Stationary_DL.Moderate.DUT.Minimum, httpSS_Stationary_DL.Poor.DUT.Minimum),
      dutMax: Math.max(httpSS_Stationary_DL.Good.DUT.Maximum, httpSS_Stationary_DL.Moderate.DUT.Maximum, httpSS_Stationary_DL.Poor.DUT.Maximum),
      refMin: Math.min(httpSS_Stationary_DL.Good.REF.Minimum, httpSS_Stationary_DL.Moderate.REF.Minimum, httpSS_Stationary_DL.Poor.REF.Minimum),
      refMax: Math.max(httpSS_Stationary_DL.Good.REF.Maximum, httpSS_Stationary_DL.Moderate.REF.Maximum, httpSS_Stationary_DL.Poor.REF.Maximum),
      dutMean: (httpSS_Stationary_DL.Good.DUT.Mean + httpSS_Stationary_DL.Moderate.DUT.Mean + httpSS_Stationary_DL.Poor.DUT.Mean) / 3,
      refMean: (httpSS_Stationary_DL.Good.REF.Mean + httpSS_Stationary_DL.Moderate.REF.Mean + httpSS_Stationary_DL.Poor.REF.Mean) / 3,
    },
  };

  const ulRangeChartData = {
    Good: {
      dutMin: httpSS_Stationary_UL.Good.DUT.Minimum,
      dutMax: httpSS_Stationary_UL.Good.DUT.Maximum,
      refMin: httpSS_Stationary_UL.Good.REF.Minimum,
      refMax: httpSS_Stationary_UL.Good.REF.Maximum,
      dutMean: httpSS_Stationary_UL.Good.DUT.Mean,
      refMean: httpSS_Stationary_UL.Good.REF.Mean,
    },
    Moderate: {
      dutMin: httpSS_Stationary_UL.Moderate.DUT.Minimum,
      dutMax: httpSS_Stationary_UL.Moderate.DUT.Maximum,
      refMin: httpSS_Stationary_UL.Moderate.REF.Minimum,
      refMax: httpSS_Stationary_UL.Moderate.REF.Maximum,
      dutMean: httpSS_Stationary_UL.Moderate.DUT.Mean,
      refMean: httpSS_Stationary_UL.Moderate.REF.Mean,
    },
    Poor: {
      dutMin: httpSS_Stationary_UL.Poor.DUT.Minimum,
      dutMax: httpSS_Stationary_UL.Poor.DUT.Maximum,
      refMin: httpSS_Stationary_UL.Poor.REF.Minimum,
      refMax: httpSS_Stationary_UL.Poor.REF.Maximum,
      dutMean: httpSS_Stationary_UL.Poor.DUT.Mean,
      refMean: httpSS_Stationary_UL.Poor.REF.Mean,
    },
    Overall: {
      dutMin: Math.min(httpSS_Stationary_UL.Good.DUT.Minimum, httpSS_Stationary_UL.Moderate.DUT.Minimum, httpSS_Stationary_UL.Poor.DUT.Minimum),
      dutMax: Math.max(httpSS_Stationary_UL.Good.DUT.Maximum, httpSS_Stationary_UL.Moderate.DUT.Maximum, httpSS_Stationary_UL.Poor.DUT.Maximum),
      refMin: Math.min(httpSS_Stationary_UL.Good.REF.Minimum, httpSS_Stationary_UL.Moderate.REF.Minimum, httpSS_Stationary_UL.Poor.REF.Minimum),
      refMax: Math.max(httpSS_Stationary_UL.Good.REF.Maximum, httpSS_Stationary_UL.Moderate.REF.Maximum, httpSS_Stationary_UL.Poor.REF.Maximum),
      dutMean: (httpSS_Stationary_UL.Good.DUT.Mean + httpSS_Stationary_UL.Moderate.DUT.Mean + httpSS_Stationary_UL.Poor.DUT.Mean) / 3,
      refMean: (httpSS_Stationary_UL.Good.REF.Mean + httpSS_Stationary_UL.Moderate.REF.Mean + httpSS_Stationary_UL.Poor.REF.Mean) / 3,
    },
  };

  const dlHistogramData = [
    { name: 'Good', DUT: httpSS_Stationary_DL.Good.DUT.Mean, REF: httpSS_Stationary_DL.Good.REF.Mean },
    { name: 'Moderate', DUT: httpSS_Stationary_DL.Moderate.DUT.Mean, REF: httpSS_Stationary_DL.Moderate.REF.Mean },
    { name: 'Poor', DUT: httpSS_Stationary_DL.Poor.DUT.Mean, REF: httpSS_Stationary_DL.Poor.REF.Mean },
    {
      name: 'Overall',
      DUT: (httpSS_Stationary_DL.Good.DUT.Mean + httpSS_Stationary_DL.Moderate.DUT.Mean + httpSS_Stationary_DL.Poor.DUT.Mean) / 3,
      REF: (httpSS_Stationary_DL.Good.REF.Mean + httpSS_Stationary_DL.Moderate.REF.Mean + httpSS_Stationary_DL.Poor.REF.Mean) / 3
    },
  ];

  const ulHistogramData = [
    { name: 'Good', DUT: httpSS_Stationary_UL.Good.DUT.Mean, REF: httpSS_Stationary_UL.Good.REF.Mean },
    { name: 'Moderate', DUT: httpSS_Stationary_UL.Moderate.DUT.Mean, REF: httpSS_Stationary_UL.Moderate.REF.Mean },
    { name: 'Poor', DUT: httpSS_Stationary_UL.Poor.DUT.Mean, REF: httpSS_Stationary_UL.Poor.REF.Mean },
    {
      name: 'Overall',
      DUT: (httpSS_Stationary_UL.Good.DUT.Mean + httpSS_Stationary_UL.Moderate.DUT.Mean + httpSS_Stationary_UL.Poor.DUT.Mean) / 3,
      REF: (httpSS_Stationary_UL.Good.REF.Mean + httpSS_Stationary_UL.Moderate.REF.Mean + httpSS_Stationary_UL.Poor.REF.Mean) / 3
    },
  ];

  const overallTableHeader = ["Throughput", "Device Name", "Download", "Upload"];
  const combinedOverallTableData = [
    ["Average (Mbps)", "DUT", ((httpSS_Stationary_DL.Good.DUT.Mean + httpSS_Stationary_DL.Moderate.DUT.Mean + httpSS_Stationary_DL.Poor.DUT.Mean) / 3).toFixed(2), ((httpSS_Stationary_UL.Good.DUT.Mean + httpSS_Stationary_UL.Moderate.DUT.Mean + httpSS_Stationary_UL.Poor.DUT.Mean) / 3).toFixed(2)],
    ["Average (Mbps)", "REF", ((httpSS_Stationary_DL.Good.REF.Mean + httpSS_Stationary_DL.Moderate.REF.Mean + httpSS_Stationary_DL.Poor.REF.Mean) / 3).toFixed(2), ((httpSS_Stationary_UL.Good.REF.Mean + httpSS_Stationary_UL.Moderate.REF.Mean + httpSS_Stationary_UL.Poor.REF.Mean) / 3).toFixed(2)],
    ["Standard Deviation (Mbps)", "DUT", ((httpSS_Stationary_DL.Good.DUT["Standard Deviation"] + httpSS_Stationary_DL.Moderate.DUT["Standard Deviation"] + httpSS_Stationary_DL.Poor.DUT["Standard Deviation"]) / 3).toFixed(2), ((httpSS_Stationary_UL.Good.DUT["Standard Deviation"] + httpSS_Stationary_UL.Moderate.DUT["Standard Deviation"] + httpSS_Stationary_UL.Poor.DUT["Standard Deviation"]) / 3).toFixed(2)],
    ["Standard Deviation (Mbps)", "REF", ((httpSS_Stationary_DL.Good.REF["Standard Deviation"] + httpSS_Stationary_DL.Moderate.REF["Standard Deviation"] + httpSS_Stationary_DL.Poor.REF["Standard Deviation"]) / 3).toFixed(2), ((httpSS_Stationary_UL.Good.REF["Standard Deviation"] + httpSS_Stationary_UL.Moderate.REF["Standard Deviation"] + httpSS_Stationary_UL.Poor.REF["Standard Deviation"]) / 3).toFixed(2)],
    ["Maximum (Mbps)", "DUT", ((httpSS_Stationary_DL.Good.DUT.Maximum + httpSS_Stationary_DL.Moderate.DUT.Maximum + httpSS_Stationary_DL.Poor.DUT.Maximum) / 3).toFixed(2), ((httpSS_Stationary_UL.Good.DUT.Maximum + httpSS_Stationary_UL.Moderate.DUT.Maximum + httpSS_Stationary_UL.Poor.DUT.Maximum) / 3).toFixed(2)],
    ["Maximum (Mbps)", "REF", ((httpSS_Stationary_DL.Good.REF.Maximum + httpSS_Stationary_DL.Moderate.REF.Maximum + httpSS_Stationary_DL.Poor.REF.Maximum) / 3).toFixed(2), ((httpSS_Stationary_UL.Good.REF.Maximum + httpSS_Stationary_UL.Moderate.REF.Maximum + httpSS_Stationary_UL.Poor.REF.Maximum) / 3).toFixed(2)],
    ["Minimum (Mbps)", "DUT", ((httpSS_Stationary_DL.Good.DUT.Minimum + httpSS_Stationary_DL.Moderate.DUT.Minimum + httpSS_Stationary_DL.Poor.DUT.Minimum) / 3).toFixed(2), ((httpSS_Stationary_UL.Good.DUT.Minimum + httpSS_Stationary_UL.Moderate.DUT.Minimum + httpSS_Stationary_UL.Poor.DUT.Minimum) / 3).toFixed(2)],
    ["Minimum (Mbps)", "REF", ((httpSS_Stationary_DL.Good.REF.Minimum + httpSS_Stationary_DL.Moderate.REF.Minimum + httpSS_Stationary_DL.Poor.REF.Minimum) / 3).toFixed(2), ((httpSS_Stationary_UL.Good.REF.Minimum + httpSS_Stationary_UL.Moderate.REF.Minimum + httpSS_Stationary_UL.Poor.REF.Minimum) / 3).toFixed(2)],
  ];


  const barKeys = [
    { key: 'DUT', fill: CHART_COLOR_DUT },
    { key: 'REF', fill: CHART_COLOR_REF },
  ];
  console.log("DUT value" + httpSS_Stationary_DL.Good.DUT);
  return (
    <>
      <div className='page-content'>
        {firstSection && <DynamicHeader level={1} style={{ textAlign: 'center' }}>Data Performance - 5G Auto </DynamicHeader>}
        <DynamicHeader level={2}>HTTP Single Stream Test Download & Upload - 5G Auto - {city}</DynamicHeader>
        <h4>Http Single Stream Overview</h4>
        <DpThroughputOverallTable
          tableHeader={overallTableHeader}
          tableData={combinedOverallTableData}
          kpiRule="Throughput"
          kpiTargetCells={[
            {
              rowIndex: 0,
              colIndex: 2,
              dutValue: ((httpSS_Stationary_DL.Good.DUT.Mean + httpSS_Stationary_DL.Moderate.DUT.Mean + httpSS_Stationary_DL.Poor.DUT.Mean) / 3).toFixed(2),
              refValue: ((httpSS_Stationary_DL.Good.REF.Mean + httpSS_Stationary_DL.Moderate.REF.Mean + httpSS_Stationary_DL.Poor.REF.Mean) / 3).toFixed(2),
            },
            {
              rowIndex: 0,
              colIndex: 3,
              dutValue: ((httpSS_Stationary_UL.Good.DUT.Mean + httpSS_Stationary_UL.Moderate.DUT.Mean + httpSS_Stationary_UL.Poor.DUT.Mean) / 3).toFixed(2),
              refValue: ((httpSS_Stationary_UL.Good.REF.Mean + httpSS_Stationary_UL.Moderate.REF.Mean + httpSS_Stationary_UL.Poor.REF.Mean) / 3).toFixed(2),
            },
          ]}
        />

        <DpDetailsTableLoc3
          data={httpSS_Stationary_DL}
          tableName="Http Single Stream DL Details"
          kpiRule="Throughput"
          kpiTargetCells={[
            {
              dutValue: (httpSS_Stationary_DL.Good.DUT.Mean + httpSS_Stationary_DL.Moderate.DUT.Mean + httpSS_Stationary_DL.Poor.DUT.Mean) / 3,
              refValue: (httpSS_Stationary_DL.Good.REF.Mean + httpSS_Stationary_DL.Moderate.REF.Mean + httpSS_Stationary_DL.Poor.REF.Mean) / 3,
            },
          ]}
        />
      </div>
      <div className='page-content'>
        <DpHistogramComponent
          data={dlHistogramData}
          title="Http Single Stream Download Throughput"
          yAxisLabel="Throughput (Mbps)"
          barKeys={barKeys}
        />
        <DpRangeChart
          data={dlRangeChartData}
          chartTitle="Http Single Stream Download Throughput Range"
          yAxisTitle="Throughput (Mbps)"
        />
      </div>

      <div className='page-content'>

        <DpDetailsTableLoc3
          data={httpSS_Stationary_UL}
          tableName="Http Single Stream UL Details"
          kpiRule="Throughput"
          kpiTargetCells={[
            {
              dutValue: (httpSS_Stationary_UL.Good.DUT.Mean + httpSS_Stationary_UL.Moderate.DUT.Mean + httpSS_Stationary_UL.Poor.DUT.Mean) / 3,
              refValue: (httpSS_Stationary_UL.Good.REF.Mean + httpSS_Stationary_UL.Moderate.REF.Mean + httpSS_Stationary_UL.Poor.REF.Mean) / 3,
            },
          ]}
        />
        <DpHistogramComponent
          data={ulHistogramData}
          title="Http Single Stream Upload Throughput"
          yAxisLabel="Throughput (Mbps)"
          barKeys={barKeys}
        />
      </div>

      <div className='page-content'>

        <DpRangeChart
          data={ulRangeChartData}
          chartTitle="Http Single Stream Upload Throughput Range"
          yAxisTitle="Throughput (Mbps)"
        />
      </div>

    </>

  );
}

export default Dp_httpSS_Component;