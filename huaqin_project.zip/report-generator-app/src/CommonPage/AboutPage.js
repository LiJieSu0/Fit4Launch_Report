import React from 'react';
import DynamicHeader from './DynamicHeader';

const AboutPage = () => {
  return (
    <div className='page-content'>
      <DynamicHeader level={1}>About ATMC Labs</DynamicHeader>
      <p>
        Advanced Test Management and Certification Labs (ATMC Labs)
        is a Seattle-based wireless device testing laboratory offering test products and services to the wireless industry.
      </p>
      <p>
        ATMC Labs was founded on the principle of distributed testing. Traditional
        “test houses” have long operated by making huge capital investments in test
        equipment and facilities to build their laboratories at a fixed location.
        This is no longer a cost-effective approach. The high equipment costs,
        rapid evolution of test equipment and test requirements and the ongoing maintenance and staffing costs
        of such facilities makes this no longer feasible. Such test houses find themselves continually compromising quality,
        coverage and cost-effectiveness to their customers so as to remain viable.
      </p>
      <p>
        ATMC Labs believes that the physical location where testing is executed is largely unimportant.
        A full range of test services are available to clients using a combination of facilities including
        our state-of-the-art accredited test laboratory in Seattle along with facilities of our various partner
        facilities including Apkudo and CTTL. With this network of providers along with US-based project management
        and advanced test management tools and systems, ATMC Labs can offer a virtual “one-stop shop” for all wireless
        device testing and certification needs with a higher efficiency, quality and cost-effectiveness compared to traditional
        test houses.
      </p>
      <p>
        With advanced communication tools, remote services and streamlined logistics, ATMC Labs has unrivaled test coverage for
        wireless devices and offers those services with the highest quality and cost effectiveness.
      </p>
    </div>
  );
};

export default AboutPage;