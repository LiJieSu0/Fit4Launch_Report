import React, { useContext, useEffect, useMemo } from 'react';
import CoverageTestTable from './CoverageTestTable';
import CoverageMap from './CoverageMap';
import { ReportContext } from '../../Contexts/ReportContext';
import DynamicHeader from '../../CommonPage/DynamicHeader';

const LteCoverageSection = ({ city: propCity, firstSection = false }) => {
    const { city: globalCity, allReportData, loadCityData, appConfig } = useContext(ReportContext);
    const city = propCity || globalCity;

    useEffect(() => {
        if (city) {
            loadCityData(city);
        }
    }, [city, loadCityData]);

    const reportData = allReportData[city];

    // Logic requested: NY uses "New York" key, Seattle uses "Seattle_LTE" key
    const getBaseStationCoords = () => {
        const defaultNY = { latitude: 40.562337, longitude: -74.695998 };
        const defaultSeattleLTE = { latitude: 47.570236, longitude: -121.888454 };

        if (!appConfig || !appConfig.coverage_station) {
            return city === "New York" ? defaultNY : defaultSeattleLTE;
        }

        const stations = appConfig.coverage_station;
        if (city === "New York") return stations["New York"] || defaultNY;
        if (city === "Seattle") return stations["Seattle_LTE"] || defaultSeattleLTE;

        return stations[city] || stations["Seattle_LTE"] || defaultSeattleLTE;
    };

    const lteBands = useMemo(() => {
        const root = reportData?.coveragePerformance?.['Coverage Performance']?.['LTE Coverage Test'];
        if (!root) return [];
        return Object.keys(root).filter(b => b.startsWith('b')).sort();
    }, [reportData]);

    const processLteCoverageData = (band, metric) => {
        const defaultRows = [
            { device: 'DUT', run1: 0, run2: 0, run3: 0, run4: 0, run5: 0, run6: 0, run7: 0, run8: 0, run9: 0, run10: 0, average: 0 },
            { device: 'REF', run1: 0, run2: 0, run3: 0, run4: 0, run5: 0, run6: 0, run7: 0, run8: 0, run9: 0, run10: 0, average: 0 },
            "N/A"
        ];

        const rootData = reportData && reportData.coveragePerformance && reportData.coveragePerformance['Coverage Performance'];
        if (!rootData || !rootData['LTE Coverage Test'] || !rootData['LTE Coverage Test'][band]) {
            return defaultRows;
        }

        const bandData = rootData['LTE Coverage Test'][band];

        const rows = ['DUT', 'REF'].map(device => {
            const deviceRuns = bandData[device] || {};
            const runData = { device };
            let sum = 0;
            let count = 0;

            for (let i = 1; i <= 10; i++) {
                const runKey = `Run${i}`;
                const runInfo = deviceRuns[runKey];
                let val = 0;
                if (runInfo && runInfo[metric] && typeof runInfo[metric].distance_km === 'number') {
                    val = runInfo[metric].distance_km;
                }

                runData[`run${i}`] = val > 0 ? parseFloat(val.toFixed(2)) : 0;

                if (val > 0) {
                    sum += val;
                    count++;
                }
            }

            runData.average = count > 0 ? parseFloat((sum / count).toFixed(2)) : 0;
            return runData;
        });

        const dutAvg = rows[0].average;
        const refAvg = rows[1].average;
        const status = (dutAvg > 0 || refAvg > 0) ? (dutAvg >= 0.95 * refAvg ? "Pass" : "Fail") : "N/A";

        return [...rows, status];
    };

    if (!reportData || !reportData.coveragePerformance) {
        return <div className="page-content">Loading {city} LTE Coverage data...</div>;
    }

    const renderBandSection = (band) => {
        const bandLabel = band.toUpperCase();
        const dataDL = processLteCoverageData(band, 'first_dl_tp_gt_1');
        const dataUL = processLteCoverageData(band, 'first_ul_tp_gt_1');

        const coords = getBaseStationCoords();
        const BASE_STATION_COORDS = [coords.latitude, coords.longitude];

        const isFirstBand = lteBands.length > 0 && band === lteBands[0];

        return (
            <div key={band}>
                <div className='page-content'>
                    {firstSection && isFirstBand && <DynamicHeader level={1}>LTE Coverage Test</DynamicHeader>}
                    <DynamicHeader level={2}>LTE Coverage Test - {bandLabel} - {city}</DynamicHeader>
                    <DynamicHeader level={3} hideInTOC={true}>LTE Coverage Test {bandLabel} - DL Throughput &lt; 1Mbps - {city}</DynamicHeader>
                    <CoverageTestTable tableData={dataDL.slice(0, -1)} status={dataDL[dataDL.length - 1]} />
                    <CoverageMap
                        bandData={reportData?.coveragePerformance?.['Coverage Performance']?.['LTE Coverage Test']?.[band]}
                        metric="first_dl_tp_gt_1"
                        baseStation={BASE_STATION_COORDS}
                    />
                </div>
                <div className='page-content'>
                    <DynamicHeader level={3} hideInTOC={true}>LTE Coverage Test {bandLabel} - UL Throughput &lt; 1Mbps - {city}</DynamicHeader>
                    <CoverageTestTable tableData={dataUL.slice(0, -1)} status={dataUL[dataUL.length - 1]} />
                    <CoverageMap
                        bandData={reportData?.coveragePerformance?.['Coverage Performance']?.['LTE Coverage Test']?.[band]}
                        metric="first_ul_tp_gt_1"
                        baseStation={BASE_STATION_COORDS}
                    />
                </div>
            </div>
        );
    };

    return (
        <>{lteBands.length > 0 ? lteBands.map(band => renderBandSection(band)) : <div className="page-content">No LTE Band data found for {city}.</div>}</>
    );
};

export default LteCoverageSection;
