import os
import sys
import json
import logging
import re

# Ensure the 'src' and all script directories are in the python path
current_file_dir = os.path.dirname(os.path.abspath(__file__)) # D:\ReportGenerator\python_scripts\src\report_generator
project_root = os.path.dirname(os.path.dirname(current_file_dir)) # D:\ReportGenerator\python_scripts

# Add key directories to sys.path to resolve imports between scripts
dirs_to_add = [
    project_root,
    os.path.join(project_root, 'src'),
    os.path.join(project_root, 'DataPerformance'),
    os.path.join(project_root, 'CallPerformance'),
    os.path.join(project_root, 'VoiceQuality'),
    os.path.join(project_root, 'Coverage'),
]

for d in dirs_to_add:
    if os.path.isdir(d) and d not in sys.path:
        sys.path.insert(0, d)

from report_generator.utils.logger import setup_logger
from report_generator.utils.config_loader import Config
from report_generator.analyzers.data_performance_analyzer import DataPerformanceAnalyzer
from report_generator.analyzers.mrab_performance_analyzer import MrabPerformanceAnalyzer
from report_generator.analyzers.call_performance_analyzer import CallPerformanceAnalyzer
from report_generator.analyzers.voice_quality_analyzer import VoiceQualityAnalyzer
from report_generator.analyzers.coverage_performance_analyzer import CoveragePerformanceAnalyzer
from report_generator.analyzers.google_throughput_analyzer import GoogleThroughputAnalyzer
from report_generator.analyzers.mhs_drive_analyzer import MHSDriveAnalyzer
from report_generator.analyzers.wfc_performance_analyzer import WfcPerformanceAnalyzer

import data_path_reader
import check_empty_data
from VoiceQuality.VqLineChartAnalyzer import calculate_vq_statistics
from Wfc.WfcLineChartAnalyzer import calculate_wfc_statistics, calculate_wfc_rssi_statistics
from Coverage.n41_coverage_analyzer import extract_coverage_data_to_csv

class DataAnalysisPipeline:
    def __init__(self, config_path="config/config.yaml", market_name=None):
        self.config = Config(config_path)
        log_config = self.config.get("logging")
        self.logger = setup_logger(
            name="pipeline", 
            log_file=log_config.get("log_file"), 
            level=log_config.get("level")
        )
        
        # Determine market: override if argument provided, otherwise fallback to config or default
        if market_name:
            self.market = market_name
        else:
            self.market = self.config.get("project.market", "Seattle")
            
        self.base_raw_data_dir = os.path.join(self.config.get("project.base_raw_data_dir"), self.market)
        self.output_dir = os.path.join(self.config.get("project.output_dir"), self.market)
        self.logger.info(f"Market: {self.market}")
        self.logger.info(f"Reading from: {self.base_raw_data_dir}")
        self.logger.info(f"Writing to: {self.output_dir}")
        os.makedirs(self.output_dir, exist_ok=True)
        
        self.results = {
            "data_performance": {},
            "call_performance": {},
            "voice_quality": {},
            "coverage": {},
            "wfc_performance": {}
        }
        
        self.processing_stats = {
            "valid_files": [],
            "invalid_files": [],
            "total_count": 0
        }
        
        # Mapping of analysis types to analyzer instances
        self.analyzers = {
            "data_performance": DataPerformanceAnalyzer(self.config, self.logger),
            "mrab_performance": MrabPerformanceAnalyzer(self.config, self.logger),
            "call_performance": CallPerformanceAnalyzer(self.config, self.logger),
            "voice_quality_combined": VoiceQualityAnalyzer(self.config, self.logger),
            "coverage_coordinate": CoveragePerformanceAnalyzer(self.config, self.logger),
            "n41_coverage": CoveragePerformanceAnalyzer(self.config, self.logger),
            "vonr_coverage_performance": CoveragePerformanceAnalyzer(self.config, self.logger),
            "google_throughput_analysis": GoogleThroughputAnalyzer(self.config, self.logger),
            "mhs_drive_performance": MHSDriveAnalyzer(self.config, self.logger),
            "wfc_performance": WfcPerformanceAnalyzer(self.config, self.logger)
        }

    def _insert_into_nested_dict(self, data_dict, path_components, value):
        """Inserts a value into a nested dictionary based on a list of path components."""
        current_level = data_dict
        for i, component in enumerate(path_components):
            if i == len(path_components) - 1:
                current_level[component] = value
            else:
                if component not in current_level:
                    current_level[component] = {}
                current_level = current_level[component]

    def _get_params(self, file_path):
        from DataPerformance import data_performance_statics
        return data_performance_statics._determine_analysis_parameters(file_path)

    def run(self):
        self.logger.info("Starting analysis pipeline...")
        
        directories_config = self.config.get("analysis.directories")
        if not directories_config:
            self.logger.error("No analysis directories configured in config.yaml")
            return

        # 1. Process individual CSV files
        excluded_types = [
            "call_performance", "voice_quality_combined", "coverage_coordinate", 
            "n41_coverage", "vonr_coverage_performance", "google_throughput_analysis", 
            "mhs_drive_performance", "wfc_performance"
        ]
        
        all_csv_files = data_path_reader.get_csv_file_paths(
            self.base_raw_data_dir, 
            directories_config, 
            excluded_analysis_types=excluded_types
        )
        
        self.logger.info(f"Processing {len(all_csv_files)} individual CSV files...")
        for csv_file_path in all_csv_files:
            params = self._get_params(csv_file_path)
            if not params: continue
            
            ana_type = params.get("analysis_type_detected")
            if ana_type in excluded_types:
                self.logger.debug(f"Skipping {csv_file_path} in file loop as it is a directory-based type ({ana_type})")
                continue
            
            analyzer = self.analyzers.get(ana_type)
            if not analyzer: continue

            stats = analyzer.analyze(csv_file_path)
            if stats and analyzer.validate(stats):
                relative_path = os.path.relpath(csv_file_path, self.base_raw_data_dir)
                path_components = relative_path.replace("\\", "/").split('/')
                
                # Strip leading category directories to avoid double nesting at export
                if path_components[0] in ["Data Performance", "Voice Quality", "Call Performance", "Coverage Performance"]:
                    path_components = path_components[1:]
                
                # Use DUT/REF as the final key instead of filename
                device_type = stats.get("Device Type", "DUT").upper()
                filename_without_ext = os.path.splitext(path_components[-1])[0].upper()
                if "REF" in filename_without_ext: device_type = "REF"
                elif "DUT" in filename_without_ext: device_type = "DUT"
                
                path_components[-1] = device_type
                
                # Insert into data_performance results
                self._insert_into_nested_dict(self.results["data_performance"], path_components, stats)
                self.processing_stats["valid_files"].append(csv_file_path)
            else:
                self.processing_stats["invalid_files"].append(csv_file_path)

        # 2. Process directory-based analysis
        self.logger.info("Processing directory-level analyses...")
        for dir_info in directories_config:
            ana_type = dir_info["analysis_type"]
            if ana_type not in excluded_types: continue
            
            analyzer = self.analyzers.get(ana_type)
            if not analyzer: continue
            
            full_path = os.path.join(self.base_raw_data_dir, dir_info["path"])
            if not os.path.isdir(full_path): continue

            if isinstance(analyzer, CoveragePerformanceAnalyzer):
                # Pass the effective market to the analyzer if needed, 
                # though currently it reads from config based on 'project.market' or hardcoded map.
                # Ideally, we should update CoveragePerformanceAnalyzer to accept market explicitly, 
                # but we updated the pipeline to handle the market context via 'self.market'
                # and CoveragePerformanceAnalyzer reads config.
                
                # Hack/Fix: CoveragePerformanceAnalyzer reads self.config.get("project.market").
                # Since we are iterating pipelines with different markets, we might need to 
                # TEMPORARILY patch the config object or pass the market to analyze method if supported.
                # However, CoveragePerformanceAnalyzer.analyze() doesn't currently take market.
                # It reads self.config.get("project.market", "Seattle").
                # To support multi-market without deep refactoring of Analyzer, 
                # we can inject the current market into the config instance in memory for this pipeline instance.
                self.config.data['project']['market'] = self.market # Inject current market into config instance
                
                stats = analyzer.analyze(full_path, analysis_type=ana_type)
            else:
                stats = analyzer.analyze(full_path)

            if stats and analyzer.validate(stats):
                # Use the leaf directory name as the nesting key if it's not a root category name
                dir_name = os.path.basename(dir_info["path"])
                root_categories = ["Data Performance", "Voice Quality", "Call Performance", "Coverage Performance"]
                
                if ana_type == "call_performance":
                    dest = self.results["call_performance"]
                    if dir_name not in root_categories:
                        if dir_name not in dest: dest[dir_name] = {}
                        dest[dir_name].update(stats)
                    else:
                        dest.update(stats)
                elif ana_type == "voice_quality_combined":
                    dest = self.results["voice_quality"]
                    if dir_name not in root_categories:
                        if dir_name not in dest: dest[dir_name] = {}
                        dest[dir_name].update(stats)
                    else:
                        dest.update(stats)
                elif ana_type in ["coverage_coordinate", "n41_coverage", "vonr_coverage_performance"]:
                    dest = self.results["coverage"]
                    if dir_name not in root_categories:
                        if dir_name not in dest: dest[dir_name] = {}
                        dest[dir_name].update(stats)
                    else:
                        dest.update(stats)
                elif ana_type in ["google_throughput_analysis", "mhs_drive_performance"]:
                    path_components = dir_info["path"].replace("\\", "/").split('/')
                    if path_components[0] in root_categories:
                        path_components = path_components[1:]
                    self._insert_into_nested_dict(self.results["data_performance"], path_components, stats)
                elif ana_type == "wfc_performance":
                    dest = self.results["wfc_performance"]
                    dest.update(stats)

        # 3. Post-processing steps
        self._run_post_processing()

        # 4. Export results
        self._export_all()
        self._export_processing_summary()
        
        # 5. Final validation
        self.logger.info("Running final data validation...")
        findings = check_empty_data.validate_json_results(self.output_dir)
        if findings:
            for line in findings:
                self.logger.warning(line)
        else:
            self.logger.info("No empty collections found in any JSON file.")
        
        self.logger.info(f"Pipeline execution completed. Results in: {self.output_dir}")

    def _run_post_processing(self):
        self.logger.info("Running post-processing (VqLineChart, Coverage extraction)...")
        
        # VQ Line Chart
        vq_linechart_dir = os.path.join(self.output_dir, "vq_linechart_data")
        os.makedirs(vq_linechart_dir, exist_ok=True)
        evs_wb_vq_paths = [
            os.path.join(self.base_raw_data_dir, r"Voice Quality\5G Auto VoNR Disabled EVS WB VQ\Base"),
            os.path.join(self.base_raw_data_dir, r"Voice Quality\5G Auto VoNR Disabled EVS WB VQ\Mobile"),
            os.path.join(self.base_raw_data_dir, r"Voice Quality\5G Auto VoNR Enabled EVS WB VQ\Base"),
            os.path.join(self.base_raw_data_dir, r"Voice Quality\5G Auto VoNR Enabled EVS WB VQ\Mobile"),
        ]
        for p in evs_wb_vq_paths:
            if os.path.isdir(p):
                scenario = os.path.basename(os.path.dirname(p)) + "_" + os.path.basename(p)
                out_path = os.path.join(vq_linechart_dir, f"vq_mos_statistics_{scenario.replace(' ', '_').lower()}.json")
                calculate_vq_statistics(p, output_json_path=out_path)

        # WFC Line Chart
        wfc_linechart_dir = os.path.join(self.output_dir, "wfc_linechart_data")
        os.makedirs(wfc_linechart_dir, exist_ok=True)
        wfc_base_path = os.path.join(self.base_raw_data_dir, "WFC")
        if os.path.isdir(wfc_base_path):
            for tc_dir in os.listdir(wfc_base_path):
                tc_path = os.path.join(wfc_base_path, tc_dir)
                if os.path.isdir(tc_path):
                    out_path = os.path.join(wfc_linechart_dir, f"wfc_mos_statistics_{tc_dir.lower()}.json")
                    calculate_wfc_statistics(tc_path, output_json_path=out_path)

        # WFC RSSI Line Chart
        wfc_rssi_linechart_dir = os.path.join(self.output_dir, "wfc_rssi_linechart_data")
        os.makedirs(wfc_rssi_linechart_dir, exist_ok=True)
        if os.path.isdir(wfc_base_path):
            for tc_dir in os.listdir(wfc_base_path):
                tc_path = os.path.join(wfc_base_path, tc_dir)
                if os.path.isdir(tc_path):
                    out_path = os.path.join(wfc_rssi_linechart_dir, f"wfc_rssi_statistics_{tc_dir.lower()}.json")
                    calculate_wfc_rssi_statistics(tc_path, output_json_path=out_path)

        # RSRP & Tx Power Extraction
        rsrp_dir = os.path.join(self.output_dir, "rsrp_data")
        tx_dir = os.path.join(self.output_dir, "tx_power_data")
        os.makedirs(rsrp_dir, exist_ok=True)
        os.makedirs(tx_dir, exist_ok=True)
        
        n41_path = os.path.join(self.base_raw_data_dir, "Coverage Performance", "5G n41 HPUE Coverage Test")
        if os.path.isdir(n41_path):
            for run in os.listdir(n41_path):
                run_p = os.path.join(n41_path, run)
                if os.path.isdir(run_p) and run.startswith("Run"):
                    extract_coverage_data_to_csv(run_p, rsrp_dir, ['PC2', 'PC3'], '[NR5G] [RF] RSRP', 'RSRP_Analysis')
                    extract_coverage_data_to_csv(run_p, tx_dir, ['PC2', 'PC3'], '[NR5G] [Power] Tx power (PUSCH Actual)', 'TxPower_Analysis', fallback_column_name='[NR5G] [Power] Tx power (Total)')
        
        # TEMPORARY MOS PATCH - Export MOS patch line chart data (overwrites histogram files)
        try:
            from report_generator.analyzers.wfc_mos_patch import apply_mos_patch
            patch_dir = os.path.join(self.base_raw_data_dir, "WFC", "MOS PATCH")
            wfc_linechart_dir = os.path.join(self.output_dir, "wfc_linechart_data")
            # Re-apply patch to export line chart data (this will overwrite histogram files)
            if os.path.isdir(patch_dir) and "wfc_performance" in self.results:
                apply_mos_patch(self.results["wfc_performance"], patch_dir, output_dir=wfc_linechart_dir, logger=self.logger)
        except Exception as e:
            self.logger.warning(f"Failed to export MOS patch line chart data: {e}")

    def _export_all(self):
        export_map = {
            "data_performance": ("data_performance_results.json", "Data Performance"),
            "call_performance": ("call_performance_results.json", "Call Performance"),
            "voice_quality": ("voice_quality_results.json", "Voice Quality"),
            "coverage": ("coverage_performance_results.json", "Coverage Performance"),
            "wfc_performance": ("wfc_performance_results.json", "WFC")
        }
        for category, (filename, root_key) in export_map.items():
            if self.results[category]:
                path = os.path.join(self.output_dir, filename)
                # Wrap the results in the category root key
                final_output = {root_key: self.results[category]}
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump(final_output, f, ensure_ascii=False, indent=4)
                self.logger.info(f"{root_key} results exported to {path}")

    def _export_processing_summary(self):
        summary_path = os.path.join(self.output_dir, "processing_summary.json")
        summary_data = {
            "market": self.market,
            "total_files_processed": len(self.processing_stats["valid_files"]) + len(self.processing_stats["invalid_files"]),
            "successfully_processed": len(self.processing_stats["valid_files"]),
            "failed_or_skipped": len(self.processing_stats["invalid_files"]),
            "valid_files": self.processing_stats["valid_files"],
            "invalid_files": self.processing_stats["invalid_files"]
        }
        with open(summary_path, 'w', encoding='utf-8') as f:
            json.dump(summary_data, f, ensure_ascii=False, indent=4)
        
        # Also generate the simple count text file for quick reference
        count_path = os.path.join(self.output_dir, "Processed File Count.txt")
        with open(count_path, 'w', encoding='utf-8') as f:
            f.write(f"Total files processed: {summary_data['total_files_processed']}\n")
            f.write(f"Correctly processed statistics: {summary_data['successfully_processed']}\n")
            f.write(f"Incorrect paths/Invalid data: {summary_data['failed_or_skipped']}\n")
        
        self.logger.info(f"Processing summary exported to {summary_path}")

if __name__ == "__main__":
    # Load config initially to get base data location
    config = Config("config/config.yaml")
    base_raw_dir = config.get("project.base_raw_data_dir")
    
    # Auto-discover markets
    if os.path.isdir(base_raw_dir):
        discovered_markets = []
        for name in os.listdir(base_raw_dir):
            if os.path.isdir(os.path.join(base_raw_dir, name)):
                # Optional: Validate against configured markets if strictness is required
                # configured_markets = config.get("markets")
                # if configured_markets and name not in configured_markets: continue
                discovered_markets.append(name)
        
        print(f"Discovered markets: {discovered_markets}")
        
        for market in discovered_markets:
            print(f"\n--- Processing Market: {market} ---")
            pipeline = DataAnalysisPipeline(market_name=market)
            pipeline.run()
    else:
        print(f"Error: Base raw data directory not found: {base_raw_dir}")

